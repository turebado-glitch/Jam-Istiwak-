import fs from 'node:fs';
import path from 'node:path';

const resDir = path.resolve('android/app/src/main/res');

const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  const permissions = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
    '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  ];

  for (const perm of permissions) {
    if (!manifest.includes(perm)) {
      manifest = manifest.replace('<application', `${perm}\n    <application`);
    }
  }
  fs.writeFileSync(manifestPath, manifest, 'utf8');
}

const stringsPath = path.join(resDir, 'values/strings.xml');
if (fs.existsSync(stringsPath)) {
  let stringsXml = fs.readFileSync(stringsPath, 'utf8');
  stringsXml = stringsXml.replace(
    /<string name="app_name">.*?<\/string>/,
    '<string name="app_name">Jam Istiwak</string>'
  );
  stringsXml = stringsXml.replace(
    /<string name="title_activity_main">.*?<\/string>/,
    '<string name="title_activity_main">Jam Istiwak</string>'
  );
  fs.writeFileSync(stringsPath, stringsXml, 'utf8');
}

// Remove Capacitor's default blue splash.png images across all drawable folders
if (fs.existsSync(resDir)) {
  for (const entry of fs.readdirSync(resDir)) {
    if (entry.startsWith('drawable')) {
      const splashFile = path.join(resDir, entry, 'splash.png');
      if (fs.existsSync(splashFile)) {
        fs.unlinkSync(splashFile);
      }
    }
  }
}

// Create transparent 1x1 shape drawable to suppress Android 12+ default icon splash
const drawableDir = path.join(resDir, 'drawable');
fs.mkdirSync(drawableDir, { recursive: true });
fs.writeFileSync(
  path.join(drawableDir, 'splash_blank.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@android:color/transparent" />
</shape>
`,
  'utf8'
);

// Remove @drawable/splash reference from AppTheme.NoActionBarLaunch so only white background shows before React SplashOverlay
const stylesPath = path.join(resDir, 'values/styles.xml');
if (fs.existsSync(stylesPath)) {
  const cleanStyles = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.Light.DarkActionBar">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryDark">@color/colorPrimaryDark</item>
        <item name="colorAccent">@color/colorAccent</item>
    </style>

    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
        <item name="android:background">@null</item>
    </style>

    <style name="AppTheme.NoActionBarLaunch" parent="AppTheme.NoActionBar">
        <item name="android:windowBackground">@android:color/white</item>
    </style>
</resources>
`;
  fs.writeFileSync(stylesPath, cleanStyles, 'utf8');
}

const valuesV31Dir = path.join(resDir, 'values-v31');
fs.mkdirSync(valuesV31Dir, { recursive: true });
fs.writeFileSync(
  path.join(valuesV31Dir, 'styles.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme.NoActionBarLaunch" parent="AppTheme.NoActionBar">
        <item name="android:windowBackground">@android:color/white</item>
        <item name="android:windowSplashScreenBackground">@android:color/white</item>
        <item name="android:windowSplashScreenAnimatedIcon">@drawable/splash_blank</item>
    </style>
</resources>
`,
  'utf8'
);

// Remove adaptive launcher XMLs so mipmap Logo 1 PNGs render cleanly without border
const anydpiDir = path.join(resDir, 'mipmap-anydpi-v26');
if (fs.existsSync(anydpiDir)) {
  for (const file of ['ic_launcher.xml', 'ic_launcher_round.xml']) {
    const target = path.join(anydpiDir, file);
    if (fs.existsSync(target)) {
      fs.unlinkSync(target);
    }
  }
}

console.log('Android manifest, white launch theme, and icon configuration updated.');
