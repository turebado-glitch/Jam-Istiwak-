import * as Astronomy from 'astronomy-engine';
import type { UserLocation } from '../types';

export const DEFAULT_LOCATION: UserLocation = {
  name: 'Prenduan, Pragaan, Sumenep',
  lat: -7.0312,
  lon: 113.8541,
  alt: 25,
};

export const MONTH_NAMES_ID = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

export const DAY_NAMES_ID = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

export function formatDateKey(dateObj: Date): string {
  const year = dateObj.getFullYear();
  const month = String(dateObj.getMonth() + 1).padStart(2, '0');
  const day = String(dateObj.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getLocalTimeZoneOffsetHours(): number {
  return -new Date().getTimezoneOffset() / 60;
}

export function getSolarTransitSeconds(dateObj: Date, location: UserLocation): number {
  try {
    const altitude = Number.isFinite(location.alt) ? location.alt : 25;
    const observer = new Astronomy.Observer(location.lat, location.lon, altitude);
    const tzOffsetHours = getLocalTimeZoneOffsetHours();
    const noonUTC = new Date(
      Date.UTC(
        dateObj.getFullYear(),
        dateObj.getMonth(),
        dateObj.getDate(),
        12 - tzOffsetHours,
        0,
        0
      )
    );
    const transitInfo = Astronomy.SearchHourAngle(Astronomy.Body.Sun, observer, 0, noonUTC);
    if (transitInfo && transitInfo.time) {
      const dTrans = new Date(transitInfo.time.date);
      const localMidnightMillis = new Date(
        Date.UTC(
          dateObj.getFullYear(),
          dateObj.getMonth(),
          dateObj.getDate(),
          0,
          0,
          0
        ) -
          tzOffsetHours * 3600000
      ).getTime();
      const transSecLocal = dTrans.getTime() - localMidnightMillis;
      const secResult = Math.floor((transSecLocal / 1000) % 86400);
      return secResult < 0 ? secResult + 86400 : secResult;
    }
  } catch (err) {
    console.error('Kesalahan perhitungan transit:', err);
  }
  return 12 * 3600;
}

export interface IstiwakSnapshot {
  istiwakFormatted: string;
  wibFormatted: string;
  transitFormatted: string;
  istiwakJam: number;
  istiwakMenit: number;
  istiwakDetik: number;
}

export function computeIstiwakSnapshot(now: Date, location: UserLocation): IstiwakSnapshot {
  const j = now.getHours();
  const m = now.getMinutes();
  const s = now.getSeconds();
  const totalSecWIB = j * 3600 + m * 60 + s;

  const transitSec = getSolarTransitSeconds(now, location);
  let diffTransit = totalSecWIB - transitSec;
  while (diffTransit < 0) diffTransit += 86400;
  while (diffTransit >= 86400) diffTransit -= 86400;

  const detikMod12 = diffTransit % 43200;
  let istiwakJam = Math.floor(detikMod12 / 3600);
  if (istiwakJam === 0) istiwakJam = 12;
  const istiwakMenit = Math.floor((detikMod12 % 3600) / 60);
  const istiwakDetik = Math.floor(detikMod12 % 60);

  const transitJam = Math.floor(transitSec / 3600);
  const transitMenit = Math.floor((transitSec % 3600) / 60);
  const transitDetik = transitSec % 60;

  const pad = (val: number) => String(val).padStart(2, '0');

  return {
    istiwakFormatted: `${pad(istiwakJam)}:${pad(istiwakMenit)}:${pad(istiwakDetik)}`,
    wibFormatted: `${pad(j)}:${pad(m)}:${pad(s)}`,
    transitFormatted: `${pad(transitJam)}:${pad(transitMenit)}:${pad(transitDetik)} WIB`,
    istiwakJam,
    istiwakMenit,
    istiwakDetik,
  };
}

export function isSecondTuesdayOfMonth(now: Date): boolean {
  const dayOfWeek = now.getDay();
  const dateOfMonth = now.getDate();
  return dayOfWeek === 2 && dateOfMonth >= 8 && dateOfMonth <= 14;
}

export function formatRemaining24h(sentAtMillis: number, nowMillis: number): string {
  const expiresAt = sentAtMillis + 24 * 60 * 60 * 1000;
  const diff = expiresAt - nowMillis;
  if (diff <= 0) return 'Kedaluwarsa';
  const totalMinutes = Math.floor(diff / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours > 0) {
    return `${hours} jam ${minutes} menit tersisa`;
  }
  return `${minutes} menit tersisa`;
}
