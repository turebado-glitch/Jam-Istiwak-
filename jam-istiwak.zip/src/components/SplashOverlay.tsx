import { useEffect, useState } from 'react';

interface SplashOverlayProps {
  onFinish: () => void;
}

export function SplashOverlay({ onFinish }: SplashOverlayProps) {
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const fadeTimer = window.setTimeout(() => {
      setFading(true);
    }, 1150);
    const doneTimer = window.setTimeout(() => {
      onFinish();
    }, 1550);

    return () => {
      window.clearTimeout(fadeTimer);
      window.clearTimeout(doneTimer);
    };
  }, [onFinish]);

  return (
    <div
      aria-label="Animasi pembuka Jam Istiwak"
      className={`fixed inset-0 z-50 flex items-center justify-center bg-white transition-opacity duration-400 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <img
        src="/assets/aistudio/AddText_11-15-02.55.07_ba0af2d4.png"
        alt="Jam Istiwak"
        referrerPolicy="no-referrer"
        className="w-[90px] h-[90px] object-contain splash-logo-anim select-none"
      />
    </div>
  );
}
