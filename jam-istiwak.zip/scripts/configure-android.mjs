import fs from 'node:fs';
import path from 'node:path';

const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  const permissions = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
    '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  ];

  for (const perm of permissions) {
    if (!manifest.includes(perm)) {
      manifest = manifest.replace('<application', `${perm}\n    <application`);
    }
  }
  fs.writeFileSync(manifestPath, manifest, 'utf8');
}

const stringsPath = path.resolve('android/app/src/main/res/values/strings.xml');
if (fs.existsSync(stringsPath)) {
  let stringsXml = fs.readFileSync(stringsPath, 'utf8');
  stringsXml = stringsXml.replace(
    /<string name="app_name">.*?<\/string>/,
    '<string name="app_name">Jam Istiwak</string>'
  );
  stringsXml = stringsXml.replace(
    /<string name="title_activity_main">.*?<\/string>/,
    '<string name="title_activity_main">Jam Istiwak</string>'
  );
  fs.writeFileSync(stringsPath, stringsXml, 'utf8');
}

const anydpiDir = path.resolve('android/app/src/main/res/mipmap-anydpi-v26');
if (fs.existsSync(anydpiDir)) {
  for (const file of ['ic_launcher.xml', 'ic_launcher_round.xml']) {
    const target = path.join(anydpiDir, file);
    if (fs.existsSync(target)) {
      fs.unlinkSync(target);
    }
  }
}

console.log('Android manifest, app name, and icon configuration updated.');
