import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'id.jamistiwak.app',
  appName: 'Jam Istiwak',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
