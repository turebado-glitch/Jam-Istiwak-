import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const resDir = path.resolve('android/app/src/main/res');

const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  const permissions = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
    '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />',
    '<uses-permission android:name="android.permission.USE_EXACT_ALARM" />',
  ];

  for (const perm of permissions) {
    if (!manifest.includes(perm)) {
      manifest = manifest.replace('<application', `${perm}\n    <application`);
    }
  }

  const receiverXml = `
        <receiver
            android:name=".RoutineAlarmReceiver"
            android:exported="false" />
        <receiver
            android:name=".BootReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>`;

  if (!manifest.includes('android:name=".RoutineAlarmReceiver"')) {
    manifest = manifest.replace('</application>', `${receiverXml}\n    </application>`);
  }

  fs.writeFileSync(manifestPath, manifest, 'utf8');
}

const stringsPath = path.join(resDir, 'values/strings.xml');
if (fs.existsSync(stringsPath)) {
  let stringsXml = fs.readFileSync(stringsPath, 'utf8');
  stringsXml = stringsXml.replace(
    /<string name="app_name">.*?<\/string>/,
    '<string name="app_name">Jam Istiwak</string>'
  );
  stringsXml = stringsXml.replace(
    /<string name="title_activity_main">.*?<\/string>/,
    '<string name="title_activity_main">Jam Istiwak</string>'
  );
  fs.writeFileSync(stringsPath, stringsXml, 'utf8');
}

// Remove Capacitor's default blue splash.png images across all drawable folders
if (fs.existsSync(resDir)) {
  for (const entry of fs.readdirSync(resDir)) {
    if (entry.startsWith('drawable')) {
      const splashFile = path.join(resDir, entry, 'splash.png');
      if (fs.existsSync(splashFile)) {
        fs.unlinkSync(splashFile);
      }
    }
  }
}

// Create transparent 1x1 shape drawable to suppress Android 12+ default icon splash
// and monochrome clock vector icon for Android status-bar notifications
const drawableDir = path.join(resDir, 'drawable');
fs.mkdirSync(drawableDir, { recursive: true });
fs.writeFileSync(
  path.join(drawableDir, 'splash_blank.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@android:color/transparent" />
</shape>
`,
  'utf8'
);

fs.writeFileSync(
  path.join(drawableDir, 'ic_stat_jam_istiwak.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8zM12.5,7H11v6l5.25,3.15 0.75,-1.23 -4.5,-2.67V7z" />
</vector>
`,
  'utf8'
);

// Remove @drawable/splash reference from AppTheme.NoActionBarLaunch so only white background shows before React SplashOverlay
const stylesPath = path.join(resDir, 'values/styles.xml');
if (fs.existsSync(stylesPath)) {
  const cleanStyles = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.Light.DarkActionBar">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryDark">@color/colorPrimaryDark</item>
        <item name="colorAccent">@color/colorAccent</item>
    </style>

    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
        <item name="android:background">@null</item>
    </style>

    <style name="AppTheme.NoActionBarLaunch" parent="AppTheme.NoActionBar">
        <item name="android:windowBackground">@android:color/white</item>
    </style>
</resources>
`;
  fs.writeFileSync(stylesPath, cleanStyles, 'utf8');
}

const valuesV31Dir = path.join(resDir, 'values-v31');
fs.mkdirSync(valuesV31Dir, { recursive: true });
fs.writeFileSync(
  path.join(valuesV31Dir, 'styles.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme.NoActionBarLaunch" parent="AppTheme.NoActionBar">
        <item name="android:windowBackground">@android:color/white</item>
        <item name="android:windowSplashScreenBackground">@android:color/white</item>
        <item name="android:windowSplashScreenAnimatedIcon">@drawable/splash_blank</item>
    </style>
</resources>
`,
  'utf8'
);

// Remove adaptive launcher XMLs so mipmap Logo 1 PNGs render cleanly without border
const anydpiDir = path.join(resDir, 'mipmap-anydpi-v26');
if (fs.existsSync(anydpiDir)) {
  for (const file of ['ic_launcher.xml', 'ic_launcher_round.xml']) {
    const target = path.join(anydpiDir, file);
    if (fs.existsSync(target)) {
      fs.unlinkSync(target);
    }
  }
}

// Install deterministic debug keystore and WorkManager dependency into android/app/build.gradle
const keystoreSrc = path.resolve('scripts/android-debug.keystore');
if (fs.existsSync(keystoreSrc)) {
  const homeAndroidDir = path.join(os.homedir(), '.android');
  fs.mkdirSync(homeAndroidDir, { recursive: true });
  fs.copyFileSync(keystoreSrc, path.join(homeAndroidDir, 'debug.keystore'));

  const appKeystoreDest = path.resolve('android/app/debug.keystore');
  fs.copyFileSync(keystoreSrc, appKeystoreDest);
}

const appGradlePath = path.resolve('android/app/build.gradle');
if (fs.existsSync(appGradlePath)) {
  let gradle = fs.readFileSync(appGradlePath, 'utf8');
  if (!gradle.includes('signingConfigs') && fs.existsSync(keystoreSrc)) {
    const signingBlock = `    signingConfigs {
        debug {
            storeFile file('debug.keystore')
            storePassword 'android'
            keyAlias 'androiddebugkey'
            keyPassword 'android'
        }
    }
    buildTypes {`;
    gradle = gradle.replace(/    buildTypes\s*\{/, signingBlock);
  }
  if (!gradle.includes('androidx.work:work-runtime')) {
    gradle = gradle.replace(
      /dependencies\s*\{/,
      `dependencies {\n    implementation "androidx.work:work-runtime:2.9.1"`
    );
  }
  fs.writeFileSync(appGradlePath, gradle, 'utf8');
}

// Generate native Android alarm scheduler, live-checked receiver, boot receiver, and background sync worker
const javaPkgDir = path.resolve('android/app/src/main/java/id/jamistiwak/app');
fs.mkdirSync(javaPkgDir, { recursive: true });

fs.writeFileSync(
  path.join(javaPkgDir, 'RoutineAlarmScheduler.java'),
  `package id.jamistiwak.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public final class RoutineAlarmScheduler {

    public static final String KEY_TIMESTAMPS_CSV = "routine_timestamps_csv";
    public static final String KEY_LOCATION_NAME = "routine_location_name";
    public static final String KEY_ROUTINE_ENABLED = "routine_enabled";
    private static final int BASE_ALARM_ID = 202601;
    private static final int MAX_ALARMS = 12;

    private RoutineAlarmScheduler() {}

    public static void saveAndSync(
        Context ctx,
        String timestampsCsv,
        String locationName,
        boolean enabled
    ) {
        SharedPreferences prefs = ctx.getSharedPreferences(
            BroadcastSyncWorker.PREFS_NAME,
            Context.MODE_PRIVATE
        );
        prefs
            .edit()
            .putString(KEY_TIMESTAMPS_CSV, timestampsCsv != null ? timestampsCsv : "")
            .putString(KEY_LOCATION_NAME, locationName != null ? locationName : "")
            .putBoolean(KEY_ROUTINE_ENABLED, enabled)
            .apply();

        cancelAll(ctx);
        if (enabled) {
            scheduleFromPrefs(ctx);
        }
    }

    public static void scheduleFromPrefs(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(
            BroadcastSyncWorker.PREFS_NAME,
            Context.MODE_PRIVATE
        );
        if (!prefs.getBoolean(KEY_ROUTINE_ENABLED, true)) {
            cancelAll(ctx);
            return;
        }

        String csv = prefs.getString(KEY_TIMESTAMPS_CSV, "");
        if (csv == null || csv.trim().isEmpty()) {
            return;
        }

        AlarmManager alarmManager = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        String locationName = prefs.getString(KEY_LOCATION_NAME, "");
        String[] parts = csv.split(",");
        long now = System.currentTimeMillis();
        boolean canExact =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms();

        int scheduledIdx = 0;
        for (String part : parts) {
            if (scheduledIdx >= MAX_ALARMS) {
                break;
            }
            try {
                long triggerMillis = Long.parseLong(part.trim());
                if (triggerMillis <= now + 2000L) {
                    continue;
                }
                int alarmId = BASE_ALARM_ID + scheduledIdx;
                Intent intent = new Intent(ctx, RoutineAlarmReceiver.class);
                intent.putExtra("location_name", locationName);
                PendingIntent pi = PendingIntent.getBroadcast(
                    ctx,
                    alarmId,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
                if (canExact) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerMillis,
                        pi
                    );
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi);
                }
                scheduledIdx++;
            } catch (NumberFormatException ignored) {
                // Skip invalid entry
            }
        }
    }

    public static void cancelAll(Context ctx) {
        AlarmManager alarmManager = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }
        for (int i = 0; i < MAX_ALARMS; i++) {
            Intent intent = new Intent(ctx, RoutineAlarmReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(
                ctx,
                BASE_ALARM_ID + i,
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
            );
            if (pi != null) {
                alarmManager.cancel(pi);
                pi.cancel();
            }
        }
    }
}
`,
  'utf8'
);

fs.writeFileSync(
  path.join(javaPkgDir, 'RoutineAlarmReceiver.java'),
  `package id.jamistiwak.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class RoutineAlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "jam_istiwak_routine";
    private static final int NOTIFICATION_ID = 202650;

    @Override
    public void onReceive(Context context, Intent intent) {
        final Context appContext = context.getApplicationContext();
        final String locationName = intent != null ? intent.getStringExtra("location_name") : "";
        final PendingResult pendingResult = goAsync();

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                boolean enabled = resolveRoutineEnabled(appContext);
                if (!enabled) {
                    return;
                }
                showRoutineNotification(appContext, locationName);
            } finally {
                pendingResult.finish();
            }
        });
    }

    private static boolean resolveRoutineEnabled(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(
            BroadcastSyncWorker.PREFS_NAME,
            Context.MODE_PRIVATE
        );
        boolean cachedEnabled = prefs.getBoolean(RoutineAlarmScheduler.KEY_ROUTINE_ENABLED, true);

        HttpURLConnection conn = null;
        try {
            URL url = new URL(BroadcastSyncWorker.FIRESTORE_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3500);
            conn.setReadTimeout(3500);

            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)
                );
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                reader.close();

                JSONObject root = new JSONObject(sb.toString());
                JSONObject fields = root.optJSONObject("fields");
                if (fields != null && fields.has("routineReminderEnabled")) {
                    JSONObject flagObj = fields.optJSONObject("routineReminderEnabled");
                    if (flagObj != null && flagObj.has("booleanValue")) {
                        boolean liveEnabled = flagObj.optBoolean("booleanValue", cachedEnabled);
                        prefs
                            .edit()
                            .putBoolean(RoutineAlarmScheduler.KEY_ROUTINE_ENABLED, liveEnabled)
                            .apply();
                        if (!liveEnabled) {
                            RoutineAlarmScheduler.cancelAll(ctx);
                        }
                        return liveEnabled;
                    }
                }
            }
        } catch (Exception ignored) {
            // Offline or timeout: fall back to cached state synced by BroadcastSyncWorker
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        return cachedEnabled;
    }

    private static void showRoutineNotification(Context ctx, String locationName) {
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return;
        }

        NotificationManager notificationManager = (NotificationManager) ctx.getSystemService(
            Context.NOTIFICATION_SERVICE
        );
        if (notificationManager == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Pengingat Acara Rutin",
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Pengingat rutin Selasa minggu ke-2 pukul 07:00 Istiwak");
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }

        Intent launchIntent = new Intent(ctx, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        launchIntent.putExtra(MainActivity.EXTRA_OPEN_ROUTINE_POPUP, true);
        PendingIntent contentIntent = PendingIntent.getActivity(
            ctx,
            NOTIFICATION_ID,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String body = "Hari ini pengajian rutin alumni";
        String detail =
            (locationName != null && !locationName.isEmpty())
                ? body + " (Pukul 07:00 Istiwak · " + locationName + ")"
                : body + " (Pukul 07:00 Istiwak)";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_jam_istiwak)
            .setColor(0xFF38BDF8)
            .setContentTitle("Pengingat Acara Rutin")
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(detail))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }
}
`,
  'utf8'
);

fs.writeFileSync(
  path.join(javaPkgDir, 'BootReceiver.java'),
  `package id.jamistiwak.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            RoutineAlarmScheduler.scheduleFromPrefs(context.getApplicationContext());
        }
    }
}
`,
  'utf8'
);

fs.writeFileSync(
  path.join(javaPkgDir, 'BroadcastSyncWorker.java'),
  `package id.jamistiwak.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import org.json.JSONObject;

public class BroadcastSyncWorker extends Worker {

    public static final String PREFS_NAME = "jam_istiwak_bg_prefs";
    public static final String KEY_SEEN_MSG_ID = "seen_msg_id";
    public static final String FIRESTORE_URL =
        "https://firestore.googleapis.com/v1/projects/global-shadow-tgt36/databases/ai-studio-049b369f-0ff5-4bc9-89f3-2b4a757005d3/documents/app_config/broadcast";
    private static final String CHANNEL_ID = "jam_istiwak_admin";
    private static final int NOTIFICATION_ID = 202699;
    private static final long TWENTY_FOUR_HOURS_MS = 24L * 60L * 60L * 1000L;

    public BroadcastSyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(FIRESTORE_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);

            int code = conn.getResponseCode();
            if (code != 200) {
                return Result.success();
            }

            BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)
            );
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();

            JSONObject root = new JSONObject(sb.toString());
            JSONObject fields = root.optJSONObject("fields");
            if (fields == null) {
                return Result.success();
            }

            Context ctx = getApplicationContext();
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

            // Sync status tombol aktif/nonaktif pengingat rutin dari Admin ke AlarmManager perangkat
            if (fields.has("routineReminderEnabled")) {
                JSONObject flagObj = fields.optJSONObject("routineReminderEnabled");
                if (flagObj != null && flagObj.has("booleanValue")) {
                    boolean routineEnabled = flagObj.optBoolean("booleanValue", true);
                    boolean prevEnabled = prefs.getBoolean(
                        RoutineAlarmScheduler.KEY_ROUTINE_ENABLED,
                        true
                    );
                    prefs
                        .edit()
                        .putBoolean(RoutineAlarmScheduler.KEY_ROUTINE_ENABLED, routineEnabled)
                        .apply();
                    if (!routineEnabled) {
                        RoutineAlarmScheduler.cancelAll(ctx);
                    } else if (!prevEnabled) {
                        RoutineAlarmScheduler.scheduleFromPrefs(ctx);
                    }
                }
            }

            String msgId = getStringField(fields, "activeMessageId");
            String msgText = getStringField(fields, "activeMessageText");
            String senderName = getStringField(fields, "senderDisplayName");
            String sentAtIso = getTimestampField(fields, "messageSentAt");

            if (msgId.isEmpty() || msgText.isEmpty() || sentAtIso.isEmpty()) {
                return Result.success();
            }

            long sentAtMillis = parseIsoUtcMillis(sentAtIso);
            if (sentAtMillis <= 0L) {
                return Result.success();
            }

            long ageMs = System.currentTimeMillis() - sentAtMillis;
            if (ageMs < -300000L || ageMs >= TWENTY_FOUR_HOURS_MS) {
                return Result.success();
            }

            String seenId = prefs.getString(KEY_SEEN_MSG_ID, "");
            if (msgId.equals(seenId)) {
                return Result.success();
            }

            if (
                Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                return Result.success();
            }

            NotificationManager notificationManager = (NotificationManager) ctx.getSystemService(
                Context.NOTIFICATION_SERVICE
            );
            if (notificationManager == null) {
                return Result.success();
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Pesan Singkat dari Admin",
                    NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("Pemberitahuan pesan singkat 24 jam dari Admin Jam Istiwak");
                channel.enableVibration(true);
                notificationManager.createNotificationChannel(channel);
            }

            Intent launchIntent = new Intent(ctx, MainActivity.class);
            launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent contentIntent = PendingIntent.getActivity(
                ctx,
                NOTIFICATION_ID,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            String title = senderName.isEmpty()
                ? "Pesan Singkat dari Admin"
                : "Pesan dari " + senderName;

            NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_jam_istiwak)
                .setColor(0xFFFBBF24)
                .setContentTitle(title)
                .setContentText(msgText)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(msgText))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(contentIntent);

            notificationManager.notify(NOTIFICATION_ID, builder.build());
            prefs.edit().putString(KEY_SEEN_MSG_ID, msgId).apply();
            return Result.success();
        } catch (Exception ignored) {
            return Result.retry();
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private static String getStringField(JSONObject fields, String key) {
        JSONObject obj = fields.optJSONObject(key);
        return obj != null ? obj.optString("stringValue", "").trim() : "";
    }

    private static String getTimestampField(JSONObject fields, String key) {
        JSONObject obj = fields.optJSONObject(key);
        return obj != null ? obj.optString("timestampValue", "").trim() : "";
    }

    private static long parseIsoUtcMillis(String iso) {
        try {
            String normalized = iso.replaceFirst("\\\\.\\\\d+Z$", "").replace("Z", "");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date parsed = sdf.parse(normalized);
            return parsed != null ? parsed.getTime() : 0L;
        } catch (Exception e) {
            return 0L;
        }
    }
}
`,
  'utf8'
);

fs.writeFileSync(
  path.join(javaPkgDir, 'MainActivity.java'),
  `package id.jamistiwak.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.getcapacitor.BridgeActivity;
import java.util.concurrent.TimeUnit;

public class MainActivity extends BridgeActivity {

    public static final String EXTRA_OPEN_ROUTINE_POPUP = "open_routine_popup";
    private static volatile boolean pendingRoutinePopup = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        captureLaunchIntent(getIntent());

        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().addJavascriptInterface(
                new JamIstiwakNativeBridge(getApplicationContext()),
                "JamIstiwakNativeBridge"
            );
        }

        Constraints constraints = new Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build();

        PeriodicWorkRequest syncRequest = new PeriodicWorkRequest.Builder(
            BroadcastSyncWorker.class,
            15,
            TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .build();

        WorkManager.getInstance(getApplicationContext()).enqueueUniquePeriodicWork(
            "jam_istiwak_broadcast_sync",
            ExistingPeriodicWorkPolicy.UPDATE,
            syncRequest
        );
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        captureLaunchIntent(intent);
    }

    private static void captureLaunchIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra(EXTRA_OPEN_ROUTINE_POPUP, false)) {
            pendingRoutinePopup = true;
        }
    }

    private static final class JamIstiwakNativeBridge {

        private final Context appContext;

        JamIstiwakNativeBridge(Context appContext) {
            this.appContext = appContext;
        }

        @JavascriptInterface
        public void markBroadcastMessageSeen(String messageId) {
            if (messageId == null || messageId.isEmpty()) {
                return;
            }
            SharedPreferences prefs = appContext.getSharedPreferences(
                BroadcastSyncWorker.PREFS_NAME,
                Context.MODE_PRIVATE
            );
            prefs.edit().putString(BroadcastSyncWorker.KEY_SEEN_MSG_ID, messageId).apply();
        }

        @JavascriptInterface
        public void syncRoutineSchedule(String timestampsCsv, String locationName, boolean enabled) {
            RoutineAlarmScheduler.saveAndSync(appContext, timestampsCsv, locationName, enabled);
        }

        @JavascriptInterface
        public boolean consumePendingRoutinePopup() {
            boolean pending = pendingRoutinePopup;
            pendingRoutinePopup = false;
            return pending;
        }
    }
}
`,
  'utf8'
);

console.log('Android manifest, white launch theme, keystore, live-checked routine alarm, and background sync worker updated.');
