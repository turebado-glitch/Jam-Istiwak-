# Security Specification: Jam Istiwak

## 1. Data Invariants
1. **Two-Admin Slot Cap**: Only `/admin_slots/slot_1` and `/admin_slots/slot_2` may exist in `admin_slots`. Once both exist, no third user may claim an admin slot or escalate privileges.
2. **Atomic Slot Claiming**: Claiming `slot_1` or `slot_2` MUST atomically update `/app_config/admin_status` in the same batch (`existsAfter`/`getAfter`) so `admin_status` never drifts from `admin_slots`.
3. **Verified Google Identity**: All admin slot claims and writes require `request.auth != null && request.auth.token.email_verified == true`.
4. **No Self-Duplication**: The same UID cannot hold both `slot_1` and `slot_2`.
5. **PII Isolation**: Email addresses in `/admin_slots/{slotId}` are strictly readable only by verified admins (`isAdmin()`). Members and unauthenticated visitors can only read `/app_config/broadcast` (zero PII).
6. **Broadcast Authority**: Only `isAdmin()` can create or update `/app_config/broadcast`. Members have read-only `get` access.
7. **Temporal Integrity**: `claimedAt`, `updatedAt`, `messageSentAt`, and `messageExpiresAt` are validated against `request.time`.

## 2. The "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. Unauthenticated write to `/app_config/broadcast` with `{ activeMessageText: "Hacked", ... }`.
2. Non-admin authenticated user writing to `/app_config/broadcast`.
3. Unverified email user (`email_verified: false`) attempting to claim `/admin_slots/slot_1`.
4. User attempting to create `/admin_slots/slot_3` (exceeding 2-admin cap).
5. User attempting to overwrite existing `/admin_slots/slot_1` via `create` or `update`.
6. User attempting to delete `/admin_slots/slot_1` or `/admin_slots/slot_2`.
7. Admin 1 attempting to claim `/admin_slots/slot_2` with their own UID (double-slot claim).
8. Spoofed email claim: user writing `{ email: "other@gmail.com", uid: request.auth.uid }` to `/admin_slots/slot_1`.
9. Non-atomic claim: creating `/admin_slots/slot_1` without updating `/app_config/admin_status` in the same batch.
10. Non-admin reading `/admin_slots/slot_1` (`get`) or listing `/admin_slots` (`list`) to scrape admin emails.
11. Shadow field injection on `/app_config/broadcast`: adding `{ extraField: true }` beyond allowed keys.
12. Oversized payload on `/app_config/broadcast`: `activeMessageText` > 500 characters or client-forged `updatedAt` != `request.time`.

## 3. Verification
All 12 payloads are covered by `firestore.rules.test.ts` and validated against the hardened `firestore.rules` structure and ESLint `@firebase/eslint-plugin-security-rules`.
