import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'id.jamistiwak.app',
  appName: 'Jam Istiwak',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  plugins: {
    SocialLogin: {
      providers: {
        google: true,
        facebook: false,
        apple: false,
        twitter: false,
      },
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_jam_istiwak',
      iconColor: '#38BDF8',
    },
  },
};

export default config;
