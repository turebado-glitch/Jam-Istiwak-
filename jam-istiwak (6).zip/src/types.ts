export interface UserLocation {
  name: string;
  lat: number;
  lon: number;
  alt: number;
}

export interface BroadcastConfig {
  routineReminderEnabled: boolean;
  activeMessageId: string;
  activeMessageText: string;
  senderDisplayName: string;
  durationHours: number;
  messageSentAtMillis: number | null;
  updatedAtMillis: number | null;
  exists: boolean;
}

export interface AdminSlotInfo {
  slot: 'slot_1' | 'slot_2';
  uid: string;
  email: string;
  displayName: string;
}

export interface AdminAuthState {
  isChecking: boolean;
  isAdmin: boolean;
  currentSlot: 'slot_1' | 'slot_2' | null;
  email: string | null;
  displayName: string | null;
  slots: AdminSlotInfo[];
  filledCount: number;
  error: string | null;
}

export type ToastKind = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: number;
  text: string;
  kind: ToastKind;
}
