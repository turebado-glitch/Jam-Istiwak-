import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { UserLocation } from '../types';
import { getUpcomingSecondTuesdayDates } from '../utils/istiwak';

export const ROUTINE_CHANNEL_ID = 'jam_istiwak_routine';
export const ADMIN_CHANNEL_ID = 'jam_istiwak_admin';

let channelsInitialized = false;

interface NativeBridgeWindow {
  JamIstiwakNativeBridge?: {
    markBroadcastMessageSeen?: (messageId: string) => void;
    syncRoutineSchedule?: (
      timestampsCsv: string,
      locationName: string,
      enabled: boolean
    ) => void;
    consumePendingRoutinePopup?: () => boolean;
  };
}

function getNativeBridge() {
  if (!Capacitor.isNativePlatform()) return undefined;
  return (window as unknown as NativeBridgeWindow).JamIstiwakNativeBridge;
}

export function markNativeBroadcastSeen(messageId: string): void {
  if (!messageId) return;
  try {
    getNativeBridge()?.markBroadcastMessageSeen?.(messageId);
  } catch {
    // Ignore when native bridge is unavailable
  }
}

export function consumeNativePendingRoutinePopup(): boolean {
  try {
    return Boolean(getNativeBridge()?.consumePendingRoutinePopup?.());
  } catch {
    return false;
  }
}

export async function initNotificationChannelsAndPermissions(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;

  try {
    if (!channelsInitialized) {
      await LocalNotifications.createChannel({
        id: ROUTINE_CHANNEL_ID,
        name: 'Pengingat Acara Rutin',
        description: 'Pengingat rutin Selasa minggu ke-2 pukul 07:00 Istiwak',
        importance: 4,
        visibility: 1,
        vibration: true,
      });
      await LocalNotifications.createChannel({
        id: ADMIN_CHANNEL_ID,
        name: 'Pesan Singkat dari Admin',
        description: 'Pemberitahuan pesan singkat 24 jam dari Admin Jam Istiwak',
        importance: 4,
        visibility: 1,
        vibration: true,
      });
      channelsInitialized = true;
    }

    const permStatus = await LocalNotifications.checkPermissions();
    if (permStatus.display === 'granted') {
      return true;
    }

    const requested = await LocalNotifications.requestPermissions();
    return requested.display === 'granted';
  } catch (err) {
    console.warn('Gagal inisialisasi izin notifikasi lokal:', err);
    return false;
  }
}

export async function syncRoutineLocalNotifications(
  location: UserLocation,
  enabled: boolean
): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;

  try {
    const granted = await initNotificationChannelsAndPermissions();
    const upcomingDates = getUpcomingSecondTuesdayDates(new Date(), location, 12);
    const timestampsCsv = upcomingDates.map((d) => String(d.getTime())).join(',');

    const bridge = getNativeBridge();
    if (bridge?.syncRoutineSchedule) {
      bridge.syncRoutineSchedule(timestampsCsv, location.name, enabled && granted);
    }
  } catch (err) {
    console.warn('Gagal menjadwalkan pengingat lokal Selasa ke-2:', err);
  }
}
