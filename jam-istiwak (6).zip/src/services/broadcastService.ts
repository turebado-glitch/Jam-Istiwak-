import type { User } from 'firebase/auth';
import {
  doc,
  getDoc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  writeBatch,
  type Unsubscribe,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type { AdminSlotInfo, BroadcastConfig } from '../types';

const BROADCAST_PATH = 'app_config/broadcast';
const ADMIN_STATUS_PATH = 'app_config/admin_status';

export const DEFAULT_BROADCAST_CONFIG: BroadcastConfig = {
  routineReminderEnabled: true,
  activeMessageId: '',
  activeMessageText: '',
  senderDisplayName: '',
  durationHours: 0,
  messageSentAtMillis: null,
  updatedAtMillis: null,
  exists: false,
};

function toMillis(value: unknown): number | null {
  if (value instanceof Timestamp) {
    return value.toMillis();
  }
  return null;
}

export function subscribeBroadcastConfig(
  onData: (config: BroadcastConfig) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const ref = doc(db, 'app_config', 'broadcast');
  return onSnapshot(
    ref,
    (snap) => {
      if (!snap.exists()) {
        onData({ ...DEFAULT_BROADCAST_CONFIG });
        return;
      }
      const data = snap.data();
      onData({
        routineReminderEnabled:
          typeof data.routineReminderEnabled === 'boolean' ? data.routineReminderEnabled : true,
        activeMessageId: typeof data.activeMessageId === 'string' ? data.activeMessageId : '',
        activeMessageText: typeof data.activeMessageText === 'string' ? data.activeMessageText : '',
        senderDisplayName: typeof data.senderDisplayName === 'string' ? data.senderDisplayName : '',
        durationHours: typeof data.durationHours === 'number' ? data.durationHours : 0,
        messageSentAtMillis: toMillis(data.messageSentAt),
        updatedAtMillis: toMillis(data.updatedAt),
        exists: true,
      });
    },
    (error) => {
      if (onError) {
        onError(error instanceof Error ? error : new Error(String(error)));
      } else {
        handleFirestoreError(error, OperationType.GET, BROADCAST_PATH);
      }
    }
  );
}

export interface ClaimResult {
  status: 'authorized' | 'quota_full' | 'unverified_email';
  currentSlot: 'slot_1' | 'slot_2' | null;
  slots: AdminSlotInfo[];
}

async function fetchRegisteredSlots(): Promise<AdminSlotInfo[]> {
  const slots: AdminSlotInfo[] = [];
  for (const slotId of ['slot_1', 'slot_2'] as const) {
    try {
      const snap = await getDoc(doc(db, 'admin_slots', slotId));
      if (snap.exists()) {
        const d = snap.data();
        slots.push({
          slot: slotId,
          uid: String(d.uid ?? ''),
          email: String(d.email ?? ''),
          displayName: String(d.displayName ?? ''),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `admin_slots/${slotId}`);
    }
  }
  return slots;
}

export async function verifyOrClaimAdminSlot(user: User): Promise<ClaimResult> {
  if (!user.emailVerified || !user.email) {
    return { status: 'unverified_email', currentSlot: null, slots: [] };
  }

  const statusRef = doc(db, 'app_config', 'admin_status');
  let statusSnap;
  try {
    statusSnap = await getDoc(statusRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, ADMIN_STATUS_PATH);
  }

  const sanitizedDisplayName = (user.displayName || user.email.split('@')[0] || 'Admin').slice(0, 100);
  const sanitizedEmail = user.email.slice(0, 254);

  if (!statusSnap.exists()) {
    const batch = writeBatch(db);
    batch.set(doc(db, 'admin_slots', 'slot_1'), {
      uid: user.uid,
      email: sanitizedEmail,
      displayName: sanitizedDisplayName,
      claimedAt: serverTimestamp(),
    });
    batch.set(statusRef, {
      slot1Uid: user.uid,
      slot2Uid: '',
      updatedAt: serverTimestamp(),
    });
    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'admin_slots/slot_1');
    }
    const slots = await fetchRegisteredSlots();
    return { status: 'authorized', currentSlot: 'slot_1', slots };
  }

  const statusData = statusSnap.data();
  const slot1Uid = typeof statusData.slot1Uid === 'string' ? statusData.slot1Uid : '';
  const slot2Uid = typeof statusData.slot2Uid === 'string' ? statusData.slot2Uid : '';

  if (slot1Uid === user.uid) {
    const slots = await fetchRegisteredSlots();
    return { status: 'authorized', currentSlot: 'slot_1', slots };
  }

  if (slot2Uid === user.uid) {
    const slots = await fetchRegisteredSlots();
    return { status: 'authorized', currentSlot: 'slot_2', slots };
  }

  if (slot1Uid && !slot2Uid) {
    const batch = writeBatch(db);
    batch.set(doc(db, 'admin_slots', 'slot_2'), {
      uid: user.uid,
      email: sanitizedEmail,
      displayName: sanitizedDisplayName,
      claimedAt: serverTimestamp(),
    });
    batch.update(statusRef, {
      slot2Uid: user.uid,
      updatedAt: serverTimestamp(),
    });
    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'admin_slots/slot_2');
    }
    const slots = await fetchRegisteredSlots();
    return { status: 'authorized', currentSlot: 'slot_2', slots };
  }

  return { status: 'quota_full', currentSlot: null, slots: [] };
}

export async function toggleRoutineReminder(
  currentConfig: BroadcastConfig,
  enabled: boolean
): Promise<void> {
  const ref = doc(db, 'app_config', 'broadcast');
  try {
    if (!currentConfig.exists) {
      await setDoc(ref, {
        routineReminderEnabled: enabled,
        activeMessageId: '',
        activeMessageText: '',
        senderDisplayName: '',
        durationHours: 0,
        messageSentAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        routineReminderEnabled: enabled,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, BROADCAST_PATH);
  }
}

export async function sendAdminBroadcastMessage(
  currentConfig: BroadcastConfig,
  rawText: string,
  senderName: string
): Promise<void> {
  const trimmed = rawText.trim().slice(0, 500);
  if (!trimmed) {
    throw new Error('Pesan tidak boleh kosong.');
  }

  const safeSender = (senderName.trim() || 'Admin').slice(0, 100);
  const msgId = `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const ref = doc(db, 'app_config', 'broadcast');

  try {
    if (!currentConfig.exists) {
      await setDoc(ref, {
        routineReminderEnabled: currentConfig.routineReminderEnabled,
        activeMessageId: msgId,
        activeMessageText: trimmed,
        senderDisplayName: safeSender,
        durationHours: 24,
        messageSentAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        activeMessageId: msgId,
        activeMessageText: trimmed,
        senderDisplayName: safeSender,
        durationHours: 24,
        messageSentAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, BROADCAST_PATH);
  }
}

export async function clearAdminBroadcastMessage(
  currentConfig: BroadcastConfig
): Promise<void> {
  if (!currentConfig.exists) return;
  const ref = doc(db, 'app_config', 'broadcast');
  try {
    await updateDoc(ref, {
      activeMessageId: '',
      activeMessageText: '',
      senderDisplayName: '',
      durationHours: 0,
      messageSentAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, BROADCAST_PATH);
  }
}
