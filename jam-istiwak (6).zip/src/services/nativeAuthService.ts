import {
  SocialLogin,
  type GoogleLoginResponseOnline,
} from '@capgo/capacitor-social-login';
import { GoogleAuthProvider, signInWithCredential, type User } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { auth } from '../firebase';

export const ANDROID_APP_PACKAGE = 'id.jamistiwak.app';
export const ANDROID_FIXED_SHA1 =
  '96:E7:9A:AD:9F:6C:62:46:00:0A:26:31:48:D7:F5:61:B2:76:42:BB';

let initPromise: Promise<void> | null = null;

export function ensureNativeSocialLoginInitialized(): Promise<void> {
  if (!initPromise) {
    initPromise = SocialLogin.initialize({
      google: {
        webClientId: firebaseConfig.oAuthClientId,
        mode: 'online',
        skipAuthOnlyAuthorizationAfterSignIn: true,
      },
    }).catch((err) => {
      initPromise = null;
      throw err;
    });
  }
  return initPromise;
}

export async function signInWithNativeGoogle(): Promise<User> {
  await ensureNativeSocialLoginInitialized();

  const res = await SocialLogin.login({
    provider: 'google',
    options: {
      style: 'standard',
      filterByAuthorizedAccounts: false,
      autoSelectEnabled: false,
    },
  });

  const googleResult = res.result as GoogleLoginResponseOnline;
  const idToken = googleResult?.idToken;

  if (!idToken) {
    throw new Error('ID Token Google tidak diterima dari perangkat Android.');
  }

  const credential = GoogleAuthProvider.credential(idToken);
  const userCred = await signInWithCredential(auth, credential);
  return userCred.user;
}

export async function signOutNativeGoogle(): Promise<void> {
  try {
    await ensureNativeSocialLoginInitialized();
    await SocialLogin.logout({ provider: 'google' });
  } catch {
    // Ignore native logout errors when already signed out
  }
}

export function formatNativeGoogleAuthError(err: unknown): string {
  const code =
    typeof err === 'object' && err !== null && 'code' in err
      ? String((err as { code?: unknown }).code)
      : '';
  const rawMessage = err instanceof Error ? err.message : String(err);
  const lower = rawMessage.toLowerCase();

  if (
    code === 'USER_CANCELLED' ||
    lower.includes('cancel') ||
    lower.includes('dibatalkan')
  ) {
    return 'Pemilihan akun Google dibatalkan.';
  }

  if (
    lower.includes('28444') ||
    lower.includes('developer console') ||
    lower.includes('not configured for this installed build') ||
    lower.includes('developer_error')
  ) {
    return `Konfigurasi SHA-1 aplikasi Android belum terdaftar di Firebase Console (${firebaseConfig.projectId}). Tambahkan aplikasi Android "${ANDROID_APP_PACKAGE}" dengan SHA-1 "${ANDROID_FIXED_SHA1}" di Firebase Project Settings.`;
  }

  if (lower.includes('no credentials available') || lower.includes('nocredential')) {
    return 'Tidak ada akun Google yang aktif di perangkat ini. Pastikan akun Google dan Google Play Services tersedia.';
  }

  if (code === 'auth/invalid-credential' || lower.includes('invalid-credential')) {
    return 'Kredensial Google tidak valid atau kedaluwarsa. Silakan pilih akun Google kembali.';
  }

  return `Login Google gagal: ${rawMessage}`;
}
