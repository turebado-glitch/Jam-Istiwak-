import { Send, X } from 'lucide-react';
import { useEffect, useState } from 'react';

interface NoteModalProps {
  open: boolean;
  dateKey: string;
  initialText: string;
  isAdmin: boolean;
  sending: boolean;
  onSaveLocal: (text: string) => void;
  onClearLocal: () => void;
  onSendBroadcast: (text: string) => Promise<void>;
  onClose: () => void;
}

export function NoteModal({
  open,
  dateKey,
  initialText,
  isAdmin,
  sending,
  onSaveLocal,
  onClearLocal,
  onSendBroadcast,
  onClose,
}: NoteModalProps) {
  const [text, setText] = useState(initialText);

  useEffect(() => {
    if (open) {
      setText(initialText);
    }
  }, [open, initialText, dateKey]);

  if (!open) return null;

  const trimmedLength = text.trim().length;

  const handleSend = async () => {
    if (!trimmedLength || sending) return;
    await onSendBroadcast(text);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="note-modal-title"
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 backdrop-blur-sm p-5"
    >
      <div className="w-full max-w-[340px] rounded-2xl border-2 border-sky-400 bg-slate-800 p-4 shadow-2xl">
        <div className="mb-2.5 flex items-center justify-between">
          <h2 id="note-modal-title" className="text-xs font-bold text-sky-400">
            Catatan: {dateKey}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup jendela catatan"
            className="flex min-h-[36px] min-w-[36px] cursor-pointer items-center justify-center rounded-lg text-slate-400 hover:bg-slate-700 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          maxLength={isAdmin ? 500 : undefined}
          placeholder={
            isAdmin
              ? 'Tulis catatan tanggal atau ketik pesan singkat untuk dikirim ke semua anggota...'
              : 'Tulis catatan di sini...'
          }
          className="h-32 w-full resize-none rounded-lg border border-slate-600 bg-slate-700 p-3 text-xs leading-relaxed text-white outline-none focus:border-sky-400 select-text"
        />

        {isAdmin && (
          <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-400">
            <span>Mode Admin aktif · Maks. 500 karakter untuk kirim pesan</span>
            <span className="font-mono tabular-nums">{trimmedLength}/500</span>
          </div>
        )}

        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={() => {
              onSaveLocal(text);
              onClose();
            }}
            className="min-h-[42px] flex-1 cursor-pointer rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500"
          >
            Simpan
          </button>
          <button
            type="button"
            onClick={() => {
              setText('');
              onClearLocal();
              onClose();
            }}
            className="min-h-[42px] flex-1 cursor-pointer rounded-lg bg-slate-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-slate-500"
          >
            Hapus
          </button>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[42px] flex-1 cursor-pointer rounded-lg bg-amber-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-amber-500"
          >
            Tutup
          </button>
        </div>

        {isAdmin && (
          <button
            type="button"
            disabled={!trimmedLength || sending}
            onClick={handleSend}
            className="mt-2.5 flex min-h-[44px] w-full cursor-pointer items-center justify-center gap-2 rounded-lg bg-amber-400 px-4 py-2 text-xs font-extrabold text-slate-950 transition-colors hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Send className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{sending ? 'Mengirim Pesan...' : 'Kirim ke Anggota (24 Jam)'}</span>
          </button>
        )}
      </div>
    </div>
  );
}
