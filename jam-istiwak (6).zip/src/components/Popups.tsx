import { MailCheck, X } from 'lucide-react';
import { formatRemaining24h } from '../utils/istiwak';

interface RoutineReminderPopupProps {
  open: boolean;
  onClose: () => void;
}

export function RoutineReminderPopup({ open, onClose }: RoutineReminderPopupProps) {
  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="routine-popup-title"
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 backdrop-blur-sm p-5"
    >
      <div className="w-full max-w-[320px] rounded-2xl border-2 border-sky-400 bg-slate-800 p-6 text-center shadow-2xl">
        <div className="mb-2.5 text-4xl" aria-hidden="true">
          📢
        </div>
        <h2 id="routine-popup-title" className="mb-2 text-base font-bold text-sky-400">
          Pengingat Acara Rutin
        </h2>
        <p className="mb-5 text-sm font-semibold leading-relaxed text-yellow-200">
          Hari ini pengajian rutin alumni
        </p>
        <button
          type="button"
          onClick={onClose}
          className="min-h-[44px] w-full cursor-pointer rounded-xl bg-sky-400 px-5 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-sky-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-300"
        >
          Tutup
        </button>
      </div>
    </div>
  );
}

interface AdminMessagePopupProps {
  open: boolean;
  messageText: string;
  senderDisplayName: string;
  sentAtMillis: number | null;
  nowMillis: number;
  onClose: () => void;
}

export function AdminMessagePopup({
  open,
  messageText,
  senderDisplayName,
  sentAtMillis,
  nowMillis,
  onClose,
}: AdminMessagePopupProps) {
  if (!open) return null;

  const sentTimeLabel = sentAtMillis
    ? new Date(sentAtMillis).toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';

  const remainingLabel = sentAtMillis ? formatRemaining24h(sentAtMillis, nowMillis) : '24 jam';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-msg-popup-title"
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 backdrop-blur-sm p-5"
    >
      <div className="w-full max-w-[340px] overflow-hidden rounded-2xl border-2 border-amber-400 bg-slate-900 shadow-2xl">
        <div className="flex items-center justify-between bg-amber-400 px-4 py-3 text-slate-950">
          <div className="flex items-center gap-2">
            <MailCheck className="h-5 w-5 shrink-0" aria-hidden="true" />
            <h2 id="admin-msg-popup-title" className="text-sm font-extrabold tracking-tight">
              Pesan Singkat dari Admin
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup pesan admin"
            className="flex min-h-[36px] min-w-[36px] cursor-pointer items-center justify-center rounded-lg text-slate-900 transition-colors hover:bg-amber-500/40"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5">
          <div className="mb-3 flex flex-wrap items-center gap-1.5 text-xs text-slate-400">
            <span>{senderDisplayName || 'Admin'}</span>
            {sentTimeLabel && (
              <>
                <span aria-hidden="true">·</span>
                <span>Pukul {sentTimeLabel}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span className="text-amber-300">{remainingLabel}</span>
          </div>

          <div className="mb-5 rounded-xl bg-slate-800/90 p-4 text-sm leading-relaxed text-slate-100 whitespace-pre-wrap break-words">
            {messageText}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] w-full cursor-pointer rounded-xl bg-amber-400 px-5 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-amber-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
          >
            Mengerti & Tutup
          </button>
        </div>
      </div>
    </div>
  );
}
