import { ChevronLeft, ChevronRight, RotateCcw, Send } from 'lucide-react';
import { DAY_NAMES_ID, formatDateKey, MONTH_NAMES_ID } from '../utils/istiwak';

interface CalendarPanelProps {
  viewDate: Date;
  todayObj: Date;
  selectedDateKey: string;
  noteText: string;
  notesVersion: number;
  isAdmin: boolean;
  sending: boolean;
  onChangeMonth: (delta: number) => void;
  onResetMonth: () => void;
  onSelectDate: (dateKey: string) => void;
  onOpenNoteModal: () => void;
  onSaveInlineNote: () => void;
  onClearInlineNote: () => void;
  onSendBroadcast: (text: string) => Promise<void>;
}

export function CalendarPanel({
  viewDate,
  todayObj,
  selectedDateKey,
  noteText,
  notesVersion,
  isAdmin,
  sending,
  onChangeMonth,
  onResetMonth,
  onSelectDate,
  onOpenNoteModal,
  onSaveInlineNote,
  onClearInlineNote,
  onSendBroadcast,
}: CalendarPanelProps) {
  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const firstDayIndex = new Date(year, month, 1).getDay();
  const totalDays = new Date(year, month + 1, 0).getDate();

  const activeDay = todayObj.getDate();
  const activeMonth = todayObj.getMonth();
  const activeYear = todayObj.getFullYear();

  const emptyCells = Array.from({ length: firstDayIndex }, (_, i) => i);
  const dayCells = Array.from({ length: totalDays }, (_, i) => i + 1);

  void notesVersion;

  return (
    <section
      aria-label="Kalender dan Catatan"
      className="w-full rounded-2xl bg-slate-800 p-4 shadow-xl"
    >
      <div className="mb-3 flex items-center justify-between">
        <button
          type="button"
          onClick={() => onChangeMonth(-1)}
          aria-label="Bulan sebelumnya"
          className="flex min-h-[40px] min-w-[40px] cursor-pointer items-center justify-center rounded-lg bg-slate-700 text-white transition-colors hover:bg-slate-600"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>

        <h2 className="text-sm font-bold text-sky-400">
          {MONTH_NAMES_ID[month]} {year}
        </h2>

        <button
          type="button"
          onClick={() => onChangeMonth(1)}
          aria-label="Bulan berikutnya"
          className="flex min-h-[40px] min-w-[40px] cursor-pointer items-center justify-center rounded-lg bg-slate-700 text-white transition-colors hover:bg-slate-600"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1 text-center">
        {DAY_NAMES_ID.map((dayName) => (
          <div key={dayName} className="pb-1.5 text-[11px] font-medium text-slate-400">
            {dayName}
          </div>
        ))}

        {emptyCells.map((idx) => (
          <div key={`empty-${idx}`} aria-hidden="true" />
        ))}

        {dayCells.map((day) => {
          const dateKey = formatDateKey(new Date(year, month, day));
          const hasNote = Boolean(localStorage.getItem(`note_${dateKey}`));
          const isToday = day === activeDay && month === activeMonth && year === activeYear;
          const isSelected = dateKey === selectedDateKey;

          return (
            <button
              key={dateKey}
              type="button"
              onClick={() => onSelectDate(dateKey)}
              className={`flex min-h-[36px] cursor-pointer flex-col items-center justify-center rounded-md text-xs transition-colors select-none ${
                isSelected
                  ? 'bg-sky-600 font-semibold text-white'
                  : 'bg-slate-700 text-slate-100 hover:bg-slate-600'
              } ${isToday ? 'ring-2 ring-yellow-400 font-bold' : ''}`}
            >
              <span className="tabular-nums">{day}</span>
              {hasNote && <span className="mt-0.5 h-1 w-1 rounded-full bg-sky-300" />}
            </button>
          );
        })}
      </div>

      <div className="mt-2.5 flex items-center justify-between">
        <span className="text-[11px] text-slate-400">Ketuk tanggal untuk melihat atau menulis catatan</span>
        <button
          type="button"
          onClick={onResetMonth}
          title="Kembali ke bulan aktif"
          aria-label="Kembali ke bulan aktif"
          className="flex min-h-[36px] min-w-[36px] cursor-pointer items-center justify-center rounded-lg bg-slate-700 text-sky-400 transition-colors hover:bg-sky-400/20 hover:text-white"
        >
          <RotateCcw className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="mt-3 rounded-xl border border-sky-400/60 bg-slate-900/75 p-3">
        <div className="mb-2 flex items-center justify-between text-xs font-bold text-sky-400">
          <span>Catatan: {selectedDateKey}</span>
          {isAdmin && <span className="text-[11px] font-semibold text-amber-300">Mode Admin</span>}
        </div>

        <textarea
          readOnly
          value={noteText}
          onClick={onOpenNoteModal}
          placeholder={
            isAdmin
              ? 'Ketuk kotak ini untuk menulis catatan atau pesan singkat untuk anggota...'
              : 'Ketuk tanggal di atas lalu ketuk kotak ini untuk menulis...'
          }
          className="h-24 w-full cursor-pointer resize-none rounded-lg border border-slate-700 bg-slate-700/80 p-2.5 text-xs leading-relaxed text-white outline-none transition-colors hover:border-sky-400/70 focus:border-sky-400 select-text"
        />

        <div className="mt-2.5 flex gap-2">
          <button
            type="button"
            onClick={onSaveInlineNote}
            className="min-h-[40px] flex-1 cursor-pointer rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500"
          >
            Simpan
          </button>
          <button
            type="button"
            onClick={onClearInlineNote}
            className="min-h-[40px] flex-1 cursor-pointer rounded-lg bg-slate-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-slate-500"
          >
            Hapus
          </button>
          {isAdmin && (
            <button
              type="button"
              disabled={!noteText.trim() || sending}
              onClick={() => onSendBroadcast(noteText)}
              className="flex min-h-[40px] flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-lg bg-amber-400 px-3 py-2 text-xs font-extrabold text-slate-950 transition-colors hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Send className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{sending ? 'Mengirim...' : 'Kirim'}</span>
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
