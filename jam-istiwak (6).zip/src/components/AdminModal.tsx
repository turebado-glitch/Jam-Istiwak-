import { Capacitor } from '@capacitor/core';
import { BellOff, BellRing, LogIn, LogOut, ShieldCheck, Trash2, X } from 'lucide-react';
import type { AdminAuthState, BroadcastConfig } from '../types';
import { formatRemaining24h } from '../utils/istiwak';

interface AdminModalProps {
  open: boolean;
  adminState: AdminAuthState;
  broadcastConfig: BroadcastConfig;
  nowMillis: number;
  busyAction: boolean;
  onLoginGoogle: () => Promise<void>;
  onLogout: () => Promise<void>;
  onToggleRoutineReminder: () => Promise<void>;
  onClearActiveMessage: () => Promise<void>;
  onClose: () => void;
}

export function AdminModal({
  open,
  adminState,
  broadcastConfig,
  nowMillis,
  busyAction,
  onLoginGoogle,
  onLogout,
  onToggleRoutineReminder,
  onClearActiveMessage,
  onClose,
}: AdminModalProps) {
  if (!open) return null;

  const isNativeCapacitor = Capacitor.isNativePlatform();

  const hasActiveBroadcast =
    Boolean(broadcastConfig.activeMessageId) &&
    Boolean(broadcastConfig.activeMessageText) &&
    broadcastConfig.messageSentAtMillis !== null &&
    nowMillis - broadcastConfig.messageSentAtMillis < 24 * 60 * 60 * 1000;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-modal-title"
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 backdrop-blur-sm p-5"
    >
      <div className="w-full max-w-[370px] rounded-2xl border border-amber-400/80 bg-slate-900 p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-amber-400" aria-hidden="true" />
            <h2 id="admin-modal-title" className="text-sm font-bold text-amber-300">
              Mode Admin Jam Istiwak
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup mode admin"
            className="flex min-h-[36px] min-w-[36px] cursor-pointer items-center justify-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {!adminState.isAdmin ? (
          <div className="space-y-4">
            <p className="text-xs leading-relaxed text-slate-300">
              {isNativeCapacitor
                ? 'Pilih akun email Google langsung di perangkat ini untuk masuk ke Mode Admin. Akses dibatasi maksimal '
                : 'Masuk menggunakan akun Google Anda untuk mengakses kontrol Admin. Akses dibatasi maksimal '}
              <strong className="text-white">2 email Admin</strong>.
            </p>

            {adminState.error && (
              <div className="rounded-xl border border-rose-500/40 bg-rose-950/60 p-3 text-xs leading-relaxed text-rose-200 break-words">
                {adminState.error}
              </div>
            )}

            <button
              type="button"
              onClick={onLoginGoogle}
              disabled={adminState.isChecking || busyAction}
              className="flex min-h-[44px] w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-extrabold text-slate-950 transition-colors hover:bg-amber-300 disabled:opacity-60"
            >
              <LogIn className="h-4 w-4" aria-hidden="true" />
              <span>
                {adminState.isChecking
                  ? 'Memeriksa Akses Admin...'
                  : busyAction
                    ? 'Membuka Pilihan Akun Google...'
                    : 'Pilih Akun Email Google'}
              </span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-xl bg-slate-800/90 p-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">
                  {adminState.displayName || 'Admin'}
                </span>
                <span className="font-mono text-[11px] text-amber-300">
                  {adminState.filledCount}/2 Slot Admin
                </span>
              </div>
              <p className="mt-0.5 truncate text-[11px] text-slate-400">{adminState.email}</p>

              {adminState.slots.length > 0 && (
                <div className="mt-2.5 border-t border-slate-700/70 pt-2 space-y-1">
                  {adminState.slots.map((s) => (
                    <div
                      key={s.slot}
                      className="flex items-center justify-between gap-2 text-[11px] text-slate-300"
                    >
                      <span className="text-slate-400">
                        {s.slot === 'slot_1' ? 'Admin 1' : 'Admin 2'}
                      </span>
                      <span className="truncate font-mono text-[11px]">{s.email}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-xl bg-slate-800/90 p-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-semibold text-white">
                    Pengingat Rutin Selasa Minggu Ke-2
                  </div>
                  <div className="mt-0.5 text-[11px] text-slate-400">
                    Muncul pukul 07:00 Istiwak ·{' '}
                    <span
                      className={
                        broadcastConfig.routineReminderEnabled ? 'text-emerald-400' : 'text-rose-400'
                      }
                    >
                      {broadcastConfig.routineReminderEnabled ? 'Aktif' : 'Nonaktif'}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  disabled={busyAction}
                  onClick={onToggleRoutineReminder}
                  className={`flex min-h-[40px] shrink-0 cursor-pointer items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold transition-colors disabled:opacity-60 ${
                    broadcastConfig.routineReminderEnabled
                      ? 'bg-rose-600 text-white hover:bg-rose-500'
                      : 'bg-emerald-600 text-white hover:bg-emerald-500'
                  }`}
                >
                  {broadcastConfig.routineReminderEnabled ? (
                    <>
                      <BellOff className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Nonaktifkan</span>
                    </>
                  ) : (
                    <>
                      <BellRing className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Aktifkan</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="rounded-xl bg-slate-800/90 p-3">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="text-xs font-semibold text-white">Pesan Aktif ke Anggota</span>
                {hasActiveBroadcast && broadcastConfig.messageSentAtMillis && (
                  <span className="text-[11px] text-amber-300">
                    {formatRemaining24h(broadcastConfig.messageSentAtMillis, nowMillis)}
                  </span>
                )}
              </div>

              {hasActiveBroadcast ? (
                <div className="space-y-2.5">
                  <p className="rounded-lg bg-slate-900/80 p-2.5 text-xs leading-relaxed text-slate-200 whitespace-pre-wrap break-words">
                    {broadcastConfig.activeMessageText}
                  </p>
                  <button
                    type="button"
                    disabled={busyAction}
                    onClick={onClearActiveMessage}
                    className="flex min-h-[40px] w-full cursor-pointer items-center justify-center gap-1.5 rounded-lg bg-slate-700 px-3 py-2 text-xs font-bold text-rose-300 transition-colors hover:bg-slate-600 disabled:opacity-60"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Hapus Pesan Aktif</span>
                  </button>
                </div>
              ) : (
                <p className="text-[11px] leading-relaxed text-slate-400">
                  Tidak ada pesan aktif. Tulis pesan singkat pada kotak{' '}
                  <strong className="text-slate-200">Catatan</strong> di bawah kalender lalu tekan{' '}
                  <strong className="text-amber-300">Kirim</strong>.
                </p>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="min-h-[42px] flex-1 cursor-pointer rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-sky-400"
              >
                Tulis di Catatan
              </button>
              <button
                type="button"
                disabled={busyAction}
                onClick={onLogout}
                className="flex min-h-[42px] cursor-pointer items-center justify-center gap-1.5 rounded-xl bg-slate-700 px-4 py-2 text-xs font-bold text-slate-200 transition-colors hover:bg-slate-600 disabled:opacity-60"
              >
                <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Keluar</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
