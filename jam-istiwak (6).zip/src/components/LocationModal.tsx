import { MapPin, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { UserLocation } from '../types';

interface LocationModalProps {
  open: boolean;
  location: UserLocation;
  onSave: (nextLocation: UserLocation) => void;
  onClose: () => void;
  onNotify: (text: string, kind?: 'success' | 'error' | 'info') => void;
}

export function LocationModal({
  open,
  location,
  onSave,
  onClose,
  onNotify,
}: LocationModalProps) {
  const [name, setName] = useState(location.name);
  const [latStr, setLatStr] = useState(String(location.lat));
  const [lonStr, setLonStr] = useState(String(location.lon));
  const [altStr, setAltStr] = useState(String(location.alt));
  const [detecting, setDetecting] = useState(false);

  useEffect(() => {
    if (open) {
      setName(location.name);
      setLatStr(String(location.lat));
      setLonStr(String(location.lon));
      setAltStr(String(location.alt));
    }
  }, [open, location]);

  if (!open) return null;

  const handleDetectGPS = () => {
    if (!navigator.geolocation) {
      onNotify('Geolocation tidak didukung oleh peramban ini.', 'error');
      return;
    }
    setDetecting(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        setLatStr(String(lat));
        setLonStr(String(lon));
        setName(`GPS (${lat.toFixed(4)}, ${lon.toFixed(4)})`);
        setDetecting(false);
        onNotify('Koordinat GPS berhasil didapatkan. Tekan Simpan untuk menerapkan.', 'info');
      },
      (err) => {
        setDetecting(false);
        onNotify(`Gagal mendeteksi GPS: ${err.message}`, 'error');
      },
      { enableHighAccuracy: true }
    );
  };

  const handleSave = () => {
    const trimmedName = name.trim();
    const lat = parseFloat(latStr);
    const lon = parseFloat(lonStr);
    const alt = parseFloat(altStr);

    if (
      !trimmedName ||
      Number.isNaN(lat) ||
      lat < -90 ||
      lat > 90 ||
      Number.isNaN(lon) ||
      lon < -180 ||
      lon > 180 ||
      Number.isNaN(alt)
    ) {
      onNotify('Nama lokasi, koordinat, atau ketinggian tidak valid.', 'error');
      return;
    }

    onSave({ name: trimmedName, lat, lon, alt });
    onClose();
    onNotify('Lokasi berhasil diperbarui.', 'success');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="location-modal-title"
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 backdrop-blur-sm p-5"
    >
      <div className="w-full max-w-[330px] rounded-2xl border border-sky-400/70 bg-slate-800 p-5 shadow-2xl">
        <div className="mb-3 flex items-center justify-between">
          <h2 id="location-modal-title" className="text-sm font-bold text-sky-400">
            Pengaturan Koordinat & Lokasi
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup pengaturan lokasi"
            className="flex min-h-[36px] min-w-[36px] cursor-pointer items-center justify-center rounded-lg text-slate-400 hover:bg-slate-700 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-2.5">
          <div>
            <label htmlFor="input-nama-lokasi" className="block text-xs text-slate-300 mb-1">
              Nama Lokasi
            </label>
            <input
              id="input-nama-lokasi"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="min-h-[40px] w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-xs text-white outline-none focus:border-sky-400"
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label htmlFor="input-lat" className="block text-xs text-slate-300 mb-1">
                Latitude (Lintang)
              </label>
              <input
                id="input-lat"
                type="text"
                value={latStr}
                onChange={(e) => setLatStr(e.target.value)}
                className="min-h-[40px] w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 font-mono text-xs text-white outline-none focus:border-sky-400"
              />
            </div>

            <div>
              <label htmlFor="input-lon" className="block text-xs text-slate-300 mb-1">
                Longitude (Bujur)
              </label>
              <input
                id="input-lon"
                type="text"
                value={lonStr}
                onChange={(e) => setLonStr(e.target.value)}
                className="min-h-[40px] w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 font-mono text-xs text-white outline-none focus:border-sky-400"
              />
            </div>
          </div>

          <div>
            <label htmlFor="input-alt" className="block text-xs text-slate-300 mb-1">
              Altitude / Ketinggian (m)
            </label>
            <input
              id="input-alt"
              type="text"
              value={altStr}
              onChange={(e) => setAltStr(e.target.value)}
              className="min-h-[40px] w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 font-mono text-xs text-white outline-none focus:border-sky-400"
            />
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button
            type="button"
            onClick={handleDetectGPS}
            disabled={detecting}
            className="flex min-h-[42px] flex-1 cursor-pointer items-center justify-center gap-1 rounded-lg bg-sky-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-sky-500 disabled:opacity-60"
          >
            <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{detecting ? 'Mencari...' : 'GPS'}</span>
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="min-h-[42px] flex-1 cursor-pointer rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500"
          >
            Simpan
          </button>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[42px] flex-1 cursor-pointer rounded-lg bg-slate-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-slate-500"
          >
            Batal
          </button>
        </div>
      </div>
    </div>
  );
}
