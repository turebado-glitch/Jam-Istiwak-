import { Capacitor } from '@capacitor/core';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { MapPin, ShieldCheck } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { AdminModal } from './components/AdminModal';
import { CalendarPanel } from './components/CalendarPanel';
import { LocationModal } from './components/LocationModal';
import { NoteModal } from './components/NoteModal';
import { AdminMessagePopup, RoutineReminderPopup } from './components/Popups';
import { SplashOverlay } from './components/SplashOverlay';
import { auth, googleProvider, testFirestoreConnection } from './firebase';
import {
  clearAdminBroadcastMessage,
  DEFAULT_BROADCAST_CONFIG,
  sendAdminBroadcastMessage,
  subscribeBroadcastConfig,
  toggleRoutineReminder,
  verifyOrClaimAdminSlot,
} from './services/broadcastService';
import {
  ensureNativeSocialLoginInitialized,
  formatNativeGoogleAuthError,
  signInWithNativeGoogle,
  signOutNativeGoogle,
} from './services/nativeAuthService';
import {
  consumeNativePendingRoutinePopup,
  initNotificationChannelsAndPermissions,
  markNativeBroadcastSeen,
  syncRoutineLocalNotifications,
} from './services/notificationService';
import type { AdminAuthState, BroadcastConfig, ToastMessage, UserLocation } from './types';
import {
  computeIstiwakSnapshot,
  DEFAULT_LOCATION,
  formatDateKey,
  isSecondTuesdayOfMonth,
  type IstiwakSnapshot,
} from './utils/istiwak';

const LOCATION_STORAGE_KEY = 'jam_istiwak_location';
const LEGACY_LOCATION_STORAGE_KEY = 'istitar_location';
const TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1000;

function loadInitialLocation(): UserLocation {
  const raw =
    localStorage.getItem(LOCATION_STORAGE_KEY) ||
    localStorage.getItem(LEGACY_LOCATION_STORAGE_KEY);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      const lat = Number(parsed.lat);
      const lon = Number(parsed.lon);
      const alt = Number(parsed.alt);
      if (
        typeof parsed.name === 'string' &&
        parsed.name.trim() &&
        Number.isFinite(lat) &&
        Number.isFinite(lon)
      ) {
        return {
          name: parsed.name,
          lat,
          lon,
          alt: Number.isFinite(alt) ? alt : 25,
        };
      }
    } catch {
      // Fallback to default location
    }
  }
  return { ...DEFAULT_LOCATION };
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [location, setLocation] = useState<UserLocation>(() => loadInitialLocation());
  const [nowMillis, setNowMillis] = useState(() => Date.now());
  const [clock, setClock] = useState<IstiwakSnapshot>(() =>
    computeIstiwakSnapshot(new Date(), loadInitialLocation())
  );

  const [todayObj, setTodayObj] = useState(() => new Date());
  const [viewDate, setViewDate] = useState(() => new Date());
  const [selectedDateKey, setSelectedDateKey] = useState(() => formatDateKey(new Date()));
  const [noteText, setNoteText] = useState(
    () => localStorage.getItem(`note_${formatDateKey(new Date())}`) || ''
  );
  const [notesVersion, setNotesVersion] = useState(0);

  const [locationModalOpen, setLocationModalOpen] = useState(false);
  const [noteModalOpen, setNoteModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [routinePopupOpen, setRoutinePopupOpen] = useState(false);
  const [dismissedAdminMsgId, setDismissedAdminMsgId] = useState<string | null>(null);

  const [broadcastConfig, setBroadcastConfig] = useState<BroadcastConfig>(
    DEFAULT_BROADCAST_CONFIG
  );

  const [adminState, setAdminState] = useState<AdminAuthState>({
    isChecking: false,
    isAdmin: false,
    currentSlot: null,
    email: null,
    displayName: null,
    slots: [],
    filledCount: 0,
    error: null,
  });

  const [busyAction, setBusyAction] = useState(false);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [isForeground, setIsForeground] = useState(() =>
    typeof document === 'undefined' ? true : document.visibilityState === 'visible'
  );

  const tapTimestampsRef = useRef<number[]>([]);
  const routineShownRef = useRef(false);
  const toastTimerRef = useRef<number | null>(null);
  const verifyingUidRef = useRef<string | null>(null);

  const showToast = useCallback(
    (text: string, kind: 'success' | 'error' | 'info' = 'info') => {
      if (toastTimerRef.current) {
        window.clearTimeout(toastTimerRef.current);
      }
      const id = Date.now();
      setToast({ id, text, kind });
      toastTimerRef.current = window.setTimeout(() => {
        setToast((prev) => (prev?.id === id ? null : prev));
      }, 3600);
    },
    []
  );

  useEffect(() => {
    testFirestoreConnection();

    if (Capacitor.isNativePlatform()) {
      ensureNativeSocialLoginInitialized().catch(() => undefined);
    }

    const unsubBroadcast = subscribeBroadcastConfig(
      (cfg) => {
        setBroadcastConfig(cfg);
      },
      (err) => {
        console.error('Gagal memuat pesan siaran:', err.message);
      }
    );
    return () => {
      unsubBroadcast();
    };
  }, []);

  useEffect(() => {
    const updateVisibility = () => {
      const visible = document.visibilityState === 'visible';
      setIsForeground(visible);
      if (visible && !showSplash && Capacitor.isNativePlatform()) {
        if (consumeNativePendingRoutinePopup()) {
          setRoutinePopupOpen(true);
        }
      }
    };

    updateVisibility();
    document.addEventListener('visibilitychange', updateVisibility);
    return () => {
      document.removeEventListener('visibilitychange', updateVisibility);
    };
  }, [showSplash]);

  useEffect(() => {
    if (showSplash || !Capacitor.isNativePlatform()) return;
    let cancelled = false;
    (async () => {
      await initNotificationChannelsAndPermissions();
      if (!cancelled) {
        await syncRoutineLocalNotifications(location, broadcastConfig.routineReminderEnabled);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [showSplash, location, broadcastConfig.routineReminderEnabled]);

  const authenticateAdminUser = useCallback(
    async (user: User, showSuccessToast = false) => {
      if (verifyingUidRef.current === user.uid) return;
      verifyingUidRef.current = user.uid;
      setAdminState((prev) => ({ ...prev, isChecking: true, error: null }));
      try {
        const result = await verifyOrClaimAdminSlot(user);
        if (result.status === 'authorized') {
          setAdminState({
            isChecking: false,
            isAdmin: true,
            currentSlot: result.currentSlot,
            email: user.email,
            displayName: user.displayName,
            slots: result.slots,
            filledCount: result.slots.length,
            error: null,
          });
          if (showSuccessToast) {
            showToast('Berhasil masuk ke Mode Admin!', 'success');
          }
        } else if (result.status === 'quota_full') {
          await signOut(auth);
          setAdminState({
            isChecking: false,
            isAdmin: false,
            currentSlot: null,
            email: null,
            displayName: null,
            slots: [],
            filledCount: 2,
            error:
              'Kuota 2 Admin sudah penuh. Email ini tidak dapat masuk ke Mode Admin.',
          });
        } else {
          await signOut(auth);
          setAdminState({
            isChecking: false,
            isAdmin: false,
            currentSlot: null,
            email: null,
            displayName: null,
            slots: [],
            filledCount: 0,
            error: 'Email Google harus terverifikasi untuk masuk ke Mode Admin.',
          });
        }
      } catch (err) {
        const raw = err instanceof Error ? err.message : String(err);
        let detail = raw;
        try {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed.error === 'string') {
            detail = `${parsed.error} (${parsed.operationType ?? 'op'} ${parsed.path ?? ''})`;
          }
        } catch {
          // Not JSON
        }
        await signOut(auth).catch(() => undefined);
        setAdminState({
          isChecking: false,
          isAdmin: false,
          currentSlot: null,
          email: null,
          displayName: null,
          slots: [],
          filledCount: 0,
          error: `Gagal memverifikasi akses Admin: ${detail}`,
        });
      } finally {
        verifyingUidRef.current = null;
      }
    },
    [showToast]
  );

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        setAdminState((prev) => ({
          isChecking: false,
          isAdmin: false,
          currentSlot: null,
          email: null,
          displayName: null,
          slots: [],
          filledCount: 0,
          error: prev.error,
        }));
        return;
      }
      await authenticateAdminUser(user, false);
    });

    return () => unsubAuth();
  }, [authenticateAdminUser]);

  useEffect(() => {
    const updateTick = () => {
      const now = new Date();
      setNowMillis(now.getTime());
      const snapshot = computeIstiwakSnapshot(now, location);
      setClock(snapshot);

      if (now.getDate() !== todayObj.getDate() || now.getMonth() !== todayObj.getMonth()) {
        setTodayObj(now);
        routineShownRef.current = false;
      }

      if (broadcastConfig.routineReminderEnabled && isSecondTuesdayOfMonth(now)) {
        const todayKey = `popup_shown_${now.getFullYear()}_${now.getMonth()}_${now.getDate()}`;
        const alreadyShownSession = sessionStorage.getItem(todayKey);
        if (
          !alreadyShownSession &&
          !routineShownRef.current &&
          snapshot.istiwakJam === 7 &&
          snapshot.istiwakMenit === 0 &&
          snapshot.istiwakDetik === 0
        ) {
          routineShownRef.current = true;
          sessionStorage.setItem(todayKey, 'true');
          setRoutinePopupOpen(true);
        }
      }
    };

    updateTick();
    const interval = window.setInterval(updateTick, 1000);
    return () => window.clearInterval(interval);
  }, [location, broadcastConfig.routineReminderEnabled, todayObj]);

  useEffect(() => {
    setNoteText(localStorage.getItem(`note_${selectedDateKey}`) || '');
  }, [selectedDateKey]);

  const handleLoginGoogle = async () => {
    setAdminState((prev) => ({ ...prev, error: null }));
    setBusyAction(true);
    try {
      if (Capacitor.isNativePlatform()) {
        const nativeUser = await signInWithNativeGoogle();
        await authenticateAdminUser(nativeUser, true);
      } else {
        const cred = await signInWithPopup(auth, googleProvider);
        if (cred.user) {
          await authenticateAdminUser(cred.user, true);
        }
      }
    } catch (err: unknown) {
      if (Capacitor.isNativePlatform()) {
        const message = formatNativeGoogleAuthError(err);
        setAdminState((prev) => ({ ...prev, error: message }));
      } else {
        const code =
          typeof err === 'object' && err !== null && 'code' in err
            ? String((err as { code?: unknown }).code)
            : '';
        const rawMessage = err instanceof Error ? err.message : String(err);
        let message = `Login Google gagal (${code || rawMessage}).`;
        if (code === 'auth/popup-closed-by-user') {
          message = 'Jendela login Google ditutup sebelum selesai.';
        } else if (code === 'auth/popup-blocked') {
          message =
            'Pop-up login diblokir oleh browser. Izinkan pop-up atau buka pratinjau aplikasi di tab baru Chrome.';
        } else if (code === 'auth/unauthorized-domain') {
          message = `Domain (${window.location.hostname}) belum terdaftar di Authorized Domains Firebase Auth.`;
        }
        setAdminState((prev) => ({ ...prev, error: message }));
      }
    } finally {
      setBusyAction(false);
    }
  };

  const handleTitleTap = () => {
    const now = Date.now();
    const recent = tapTimestampsRef.current.filter((t) => now - t <= 2500);
    recent.push(now);
    tapTimestampsRef.current = recent;

    if (recent.length >= 3) {
      tapTimestampsRef.current = [];
      setAdminState((prev) => ({ ...prev, error: null }));
      setAdminModalOpen(true);

      if (
        Capacitor.isNativePlatform() &&
        !adminState.isAdmin &&
        !adminState.isChecking &&
        !busyAction
      ) {
        void handleLoginGoogle();
      }
    }
  };

  const handleSaveLocation = (nextLoc: UserLocation) => {
    setLocation(nextLoc);
    localStorage.setItem(LOCATION_STORAGE_KEY, JSON.stringify(nextLoc));
    localStorage.setItem(LEGACY_LOCATION_STORAGE_KEY, JSON.stringify(nextLoc));
  };

  const handleSaveLocalNote = (text: string) => {
    if (text.trim() === '') {
      localStorage.removeItem(`note_${selectedDateKey}`);
      setNoteText('');
    } else {
      localStorage.setItem(`note_${selectedDateKey}`, text);
      setNoteText(text);
    }
    setNotesVersion((v) => v + 1);
    showToast('Catatan berhasil disimpan!', 'success');
  };

  const handleClearLocalNote = () => {
    localStorage.removeItem(`note_${selectedDateKey}`);
    setNoteText('');
    setNotesVersion((v) => v + 1);
    showToast('Catatan tanggal dihapus.', 'info');
  };

  const handleLogoutAdmin = async () => {
    setBusyAction(true);
    try {
      await signOut(auth);
      if (Capacitor.isNativePlatform()) {
        await signOutNativeGoogle();
      }
      setAdminState({
        isChecking: false,
        isAdmin: false,
        currentSlot: null,
        email: null,
        displayName: null,
        slots: [],
        filledCount: 0,
        error: null,
      });
      showToast('Berhasil keluar dari Mode Admin.', 'info');
    } finally {
      setBusyAction(false);
    }
  };

  const handleToggleRoutineReminder = async () => {
    setBusyAction(true);
    try {
      const nextValue = !broadcastConfig.routineReminderEnabled;
      await toggleRoutineReminder(broadcastConfig, nextValue);
      showToast(
        nextValue
          ? 'Pengingat otomatis Selasa minggu ke-2 diaktifkan.'
          : 'Pengingat otomatis Selasa minggu ke-2 dinonaktifkan.',
        'success'
      );
    } catch {
      showToast('Gagal mengubah status pengingat rutin.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const handleSendBroadcast = async (rawText: string) => {
    if (!adminState.isAdmin) return;
    setBusyAction(true);
    try {
      await sendAdminBroadcastMessage(
        broadcastConfig,
        rawText,
        adminState.displayName || adminState.email || 'Admin'
      );
      showToast('Pesan singkat berhasil dikirim ke semua anggota (berlaku 24 jam).', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Gagal mengirim pesan.';
      showToast(msg, 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const handleClearActiveMessage = async () => {
    setBusyAction(true);
    try {
      await clearAdminBroadcastMessage(broadcastConfig);
      showToast('Pesan singkat aktif berhasil dihapus.', 'info');
    } catch {
      showToast('Gagal menghapus pesan aktif.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const isBroadcastValid24h =
    Boolean(broadcastConfig.activeMessageId) &&
    Boolean(broadcastConfig.activeMessageText) &&
    broadcastConfig.messageSentAtMillis !== null &&
    nowMillis - broadcastConfig.messageSentAtMillis < TWENTY_FOUR_HOURS_MS;

  const isAlreadySeenOnDevice = broadcastConfig.activeMessageId
    ? localStorage.getItem(`jam_istiwak_seen_${broadcastConfig.activeMessageId}`) === '1'
    : true;

  const shouldShowAdminPopup =
    !showSplash &&
    isForeground &&
    isBroadcastValid24h &&
    !isAlreadySeenOnDevice &&
    dismissedAdminMsgId !== broadcastConfig.activeMessageId;

  useEffect(() => {
    if (shouldShowAdminPopup && isForeground && broadcastConfig.activeMessageId) {
      markNativeBroadcastSeen(broadcastConfig.activeMessageId);
    }
  }, [shouldShowAdminPopup, isForeground, broadcastConfig.activeMessageId]);

  const handleCloseAdminPopup = () => {
    if (broadcastConfig.activeMessageId) {
      localStorage.setItem(`jam_istiwak_seen_${broadcastConfig.activeMessageId}`, '1');
      markNativeBroadcastSeen(broadcastConfig.activeMessageId);
      setDismissedAdminMsgId(broadcastConfig.activeMessageId);
    }
  };

  const handleSplashFinish = useCallback(() => {
    setShowSplash(false);
  }, []);

  return (
    <div className="min-h-screen bg-[#0f172a] text-white px-4 pt-6 pb-12 sm:px-6">
      {showSplash && <SplashOverlay onFinish={handleSplashFinish} />}

      {adminState.isAdmin && (
        <div className="mx-auto mb-4 flex w-full max-w-[380px] items-center justify-between gap-2 rounded-xl border border-amber-400/70 bg-amber-400/10 px-3.5 py-2.5 lg:max-w-4xl">
          <div className="flex min-w-0 items-center gap-2">
            <ShieldCheck className="h-4 w-4 shrink-0 text-amber-400" aria-hidden="true" />
            <div className="min-w-0">
              <div className="text-xs font-bold text-amber-300">Mode Admin Aktif</div>
              <div className="truncate text-[11px] text-slate-300">{adminState.email}</div>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <button
              type="button"
              onClick={() => setAdminModalOpen(true)}
              className="min-h-[36px] cursor-pointer rounded-lg bg-amber-400 px-3 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-300"
            >
              Panel Admin
            </button>
          </div>
        </div>
      )}

      <main className="mx-auto w-full max-w-[380px] lg:max-w-4xl">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12 lg:gap-8 lg:items-start">
          {/* Kolom Kiri: Header Logo, Jam Istiwak, Info Transit */}
          <div className="flex flex-col items-center lg:col-span-5">
            <header className="mb-4 flex flex-col items-center text-center">
              <img
                src="/assets/aistudio/AddText_11-15-02.54.03_e415f4f9.png"
                alt="Logo Jam Istiwak"
                referrerPolicy="no-referrer"
                className="mb-2 h-14 w-14 object-contain border-0 ring-0 shadow-none bg-transparent select-none"
              />
              <h1
                onClick={handleTitleTap}
                className="cursor-pointer touch-manipulation text-xl font-extrabold tracking-tight text-sky-400 select-none"
              >
                Jam Istiwak
              </h1>
              <button
                type="button"
                onClick={() => setLocationModalOpen(true)}
                title="Ketuk untuk ubah lokasi"
                className="mt-1 inline-flex min-h-[36px] cursor-pointer items-center gap-1 rounded-md px-2.5 py-1 text-xs text-slate-400 transition-colors hover:bg-slate-800 hover:text-white"
              >
                <MapPin className="h-3.5 w-3.5 shrink-0 text-sky-400/80" aria-hidden="true" />
                <span>{location.name}</span>
              </button>
            </header>

            <section
              aria-label="Jam Istiwak Saat Ini"
              className="mb-3 w-full max-w-[320px] rounded-2xl border-2 border-sky-400 bg-slate-800 px-4 py-5 text-center shadow-xl"
            >
              <div className="text-[11px] font-semibold tracking-widest text-slate-400 uppercase">
                Waktu Istiwak
              </div>
              <div className="my-2 font-mono text-4xl font-extrabold tracking-wider text-yellow-400 tabular-nums sm:text-[42px]">
                {clock.istiwakFormatted}
              </div>
              <div className="mt-3 border-t border-white/10 pt-2.5 text-xs text-slate-400">
                WIB:{' '}
                <span className="font-mono font-medium text-slate-200 tabular-nums">
                  {clock.wibFormatted}
                </span>
              </div>
            </section>

            <section
              aria-label="Informasi Transit Matahari"
              className="w-full max-w-[360px] rounded-xl bg-slate-800 px-4 py-3 text-xs shadow-md"
            >
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-400">Transit Matahari:</span>
                <strong className="font-mono font-bold text-slate-100 tabular-nums">
                  {clock.transitFormatted}
                </strong>
              </div>
            </section>
          </div>

          {/* Kolom Kanan: Kalender & Panel Catatan */}
          <div className="mx-auto w-full max-w-[360px] lg:col-span-7 lg:max-w-none">
            <CalendarPanel
              viewDate={viewDate}
              todayObj={todayObj}
              selectedDateKey={selectedDateKey}
              noteText={noteText}
              notesVersion={notesVersion}
              isAdmin={adminState.isAdmin}
              sending={busyAction}
              onChangeMonth={(delta) =>
                setViewDate((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1))
              }
              onResetMonth={() => {
                const now = new Date();
                setTodayObj(now);
                setViewDate(now);
                setSelectedDateKey(formatDateKey(now));
              }}
              onSelectDate={(key) => setSelectedDateKey(key)}
              onOpenNoteModal={() => setNoteModalOpen(true)}
              onSaveInlineNote={() => handleSaveLocalNote(noteText)}
              onClearInlineNote={handleClearLocalNote}
              onSendBroadcast={handleSendBroadcast}
            />
          </div>
        </div>
      </main>

      {/* Pop-up Pengingat Acara Rutin (Selasa Minggu Ke-2, 07:00 Istiwak) */}
      <RoutineReminderPopup
        open={routinePopupOpen}
        onClose={() => setRoutinePopupOpen(false)}
      />

      {/* Pop-up Pesan Singkat dari Admin (Tampil 1x, Berlaku 24 Jam, Desain Berbeda) */}
      <AdminMessagePopup
        open={shouldShowAdminPopup}
        messageText={broadcastConfig.activeMessageText}
        senderDisplayName={broadcastConfig.senderDisplayName}
        sentAtMillis={broadcastConfig.messageSentAtMillis}
        nowMillis={nowMillis}
        onClose={handleCloseAdminPopup}
      />

      {/* Modal Tulis/Edit Catatan + Kirim Pesan Admin */}
      <NoteModal
        open={noteModalOpen}
        dateKey={selectedDateKey}
        initialText={noteText}
        isAdmin={adminState.isAdmin}
        sending={busyAction}
        onSaveLocal={handleSaveLocalNote}
        onClearLocal={handleClearLocalNote}
        onSendBroadcast={handleSendBroadcast}
        onClose={() => setNoteModalOpen(false)}
      />

      {/* Modal Pengaturan Lokasi & GPS */}
      <LocationModal
        open={locationModalOpen}
        location={location}
        onSave={handleSaveLocation}
        onClose={() => setLocationModalOpen(false)}
        onNotify={showToast}
      />

      {/* Modal Mode Admin (Dibuka dengan Ketuk "Jam Istiwak" 3 Kali) */}
      <AdminModal
        open={adminModalOpen}
        adminState={adminState}
        broadcastConfig={broadcastConfig}
        nowMillis={nowMillis}
        busyAction={busyAction}
        onLoginGoogle={handleLoginGoogle}
        onLogout={handleLogoutAdmin}
        onToggleRoutineReminder={handleToggleRoutineReminder}
        onClearActiveMessage={handleClearActiveMessage}
        onClose={() => setAdminModalOpen(false)}
      />

      {/* Notifikasi Toast Ringkas */}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="pointer-events-none fixed inset-x-0 bottom-5 z-50 flex justify-center px-4"
        >
          <div
            className={`max-w-sm rounded-xl border px-4 py-2.5 text-xs font-semibold shadow-xl ${
              toast.kind === 'error'
                ? 'border-rose-400/60 bg-rose-950/95 text-rose-100'
                : toast.kind === 'success'
                  ? 'border-emerald-400/60 bg-emerald-950/95 text-emerald-100'
                  : 'border-sky-400/60 bg-slate-800/95 text-slate-100'
            }`}
          >
            {toast.text}
          </div>
        </div>
      )}
    </div>
  );
}
