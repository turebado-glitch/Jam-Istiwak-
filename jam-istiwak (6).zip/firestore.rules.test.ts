/**
 * Security test specification for Jam Istiwak Firestore rules.
 * Covers the 12 "Dirty Dozen" adversarial payloads defined in security_spec.md.
 */

export const dirtyDozenSecurityCases = [
  {
    id: 1,
    name: 'Unauthenticated write to /app_config/broadcast',
    path: '/app_config/broadcast',
    operation: 'write',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Non-admin authenticated write to /app_config/broadcast',
    path: '/app_config/broadcast',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Unverified email user claiming /admin_slots/slot_1',
    path: '/admin_slots/slot_1',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Attempt to create /admin_slots/slot_3 beyond 2-slot cap',
    path: '/admin_slots/slot_3',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Attempt to overwrite existing /admin_slots/slot_1',
    path: '/admin_slots/slot_1',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Attempt to delete /admin_slots/slot_1 or slot_2',
    path: '/admin_slots/slot_1',
    operation: 'delete',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Admin 1 claiming /admin_slots/slot_2 with same UID',
    path: '/admin_slots/slot_2',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Email spoofing in /admin_slots/slot_1 claim',
    path: '/admin_slots/slot_1',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Non-atomic claim without updating /app_config/admin_status',
    path: '/admin_slots/slot_1',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Non-admin reading or listing /admin_slots PII',
    path: '/admin_slots/slot_1',
    operation: 'get',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Shadow field injection on /app_config/broadcast',
    path: '/app_config/broadcast',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Oversized message (>500 chars) or client-forged timestamp',
    path: '/app_config/broadcast',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
  },
] as const;
